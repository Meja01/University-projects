# Assignment 2: Simplified version of Prime Climb
## Lernziel
In diesem Assignemtn soll der Umgang mit Funktionen, Pointern, Structs, Kommandozeilenargumente und die generelle Strukturierung und Implementierung gelernt werden. Um die definierten Lernziele zu erreichen soll ein Programm mit der folgenden definierten Funktionalität implementiert werden.

## Beschreibung 
Ziel ist es, eine vereinfachte Kommandozeilen-Version des beliebten Brettspiels "Prime Climb" zu implementieren. In diesem Spiel sind die Kenntnisse und Skills sowohl im Bereich der Primzahlen als auch dem Kopfrechnen gefragt - es verspricht Spaß für Groß und Klein.
Das Spiel besteht aus einem Spielfeld welches alle Zahlen von 0 bis eine Primzahl von beliebiger Größe darstellt (im original Brettspiel 101). Jede der Zahlen wird dabei visuell in ihre Primfaktoren zerlegt dargestellt. Nun können 2-4 Spieler mit Hilfe der vier Grundrechenarten ihren Weg zur höchsten Primzahl bestreiten. Welche Zahl für die Rechenoperationen verwendet werden muss, wird durch das Würfeln zweier 10 seitiger Würfel ermittelt. Da die Endzahl eine Primzahl ist, muss die letzte Operation dabei immer eine Addition sein. Zusätzlich kann ein Spieler einen anderen Spieler zurück zum Anfang schicken, wenn dieser am gleichen Feld landet. Gewonnen hat der Spieler, der als erstes die höchste Primzahl des Spielfeldes erreicht hat. Soviel zur Theorie. Uns interessiert allerdings nur, wie wir dieses Brettspiel in die Kommandozeile bringen können. Dafür kann der User den Randomseed, die Anzahl der Spieler sowie die Anzahl der Spielfelder bestimmen. Anschließend beginnt das Spiel rundenbasiert, jeder Spieler kann mithilfe von Commands Addieren, Subtrahieren, Multiplizieren oder Dividieren um als erstes am letzten Spielfeld zu landen. Bei jedem Spielzug wird das Spielfeld neu ausgegeben um die Position der Spieler darzustellen.
Genauere Infos zu dem Spiel und wie das Original gespielt wird, findest du [hier - English](https://www.youtube.com/watch?v=usBHrp6s4xY) sowie [hier - Deutsch](https://youtu.be/AczyQwO61MA). 

## Programmaufruf und Ablauf
Das Programm soll mit 3 Kommandozeilenargumenten aufgerufen werden können:
```
./primeclimb <seed> <number of players> <number of fields>
```
**primeclimb**: Programmname


1. **Argument**: Seed der benötigt wird um die Zufallszahlen der Würfel zu generieren
2. **Argument**: Anzahl der Spieler (1 bis 3)
3. **Argument**: Anzahl der Spielfelder bzw. Zahl des Zielfeldes (muss eine Primzahl sein!)

Beispiel:
- $./primeclimb 2022 2 11

Direkt nach dem Spielstart soll den Spielern der gewählte Seed für die Randomfunktion angezeigt werden: 
```
Chosen seed was: 2022\n
```

Daraufhin soll das Programm die Spieler nacheinander nach einem gewünschten ASCII-Zeichen als Spielfigur, welches auf dem Spielfeld angezeigt wird, fragen. In unserem Beispiel entscheidet sich Player 1 für "*" und Player 2 für "#":
```
Enter symbol for player 1: *
Enter symbol for player 2: #
```
Sollte eine Spielfigur doppelt eingegeben werden, soll folgende Fehlermeldung ausgegeben und erneut nach einer validen Eingabe gefragt werden:
```
Was already chosen by player %d, enter again!\n
```

Danach startet bereits der erste Spielzug.
### Spielzug
Die Spieler kommen nacheinander zum Zug. In jedem Spielzug wird das Spielfeld mit der aktuellen Position der Spielfiguren, der Spieler welcher am Zug ist, die aktuell gewürfelten Zufallszahlen (welche noch nicht verwendet wurden) sowie die möglichen Rechenoperationen ausgegeben.

In jedem Zug wird pro Spieler 2 mal gewürfelt und pro Wurf eine Rechenoperationen gewählt/angewandt.

Nach jeder Rechenoperation wird das Spielfeld, die noch nicht verwendeten Würfelergebnisse sowie die möglichen Rechenoperationen ausgegeben. Der Spieler kann daraufhin seine gewünscht Rechenoperation eingeben.
### Spielfeld
Das Spielfeld besteht aus dem Header:
```
-------------------------------------------------\n
|Player\t\tField\t\tPrime Factors\t|\n
-------------------------------------------------\n
```
Den entsprechenden Werten:
```
<Player>\t\t<Fieldnumber>\t\t<PrimeFactors>\n
```
> **_ACHTUNG:_** Achte besonders darauf, die Werte mit den entsprechenden Header Überschriften zu alignen!

**Wichtig**
Die Primfaktoren sollen, um der Originalvorlage möglichst nah zu kommen, [farblich](https://www.theurbanpenguin.com/4184-2/) im Terminal wiedergeben werden.  Um dies zu erreichen und keine Probleme mit dem Testsystem zu erzeugen, soll jede farbige Ausgabe **ohne** Lehrzeichen **oder** Sonderzeichen wie \n, \t etc. getätigt werden. Wir geben dafür folgenden Befehl vor mit welchem jeder Primfaktor ausgegeben werden sollte:
```
printf("%s%d%s", color, number, without_color);
```

|Prime number| Color | Value for printf |
| ----- | ------ | ------ |
|2| Yellow | \033[0;33m |
|3| Green | \033[0;32m |
|5| Blue | \033[0;34m |
|7| Purple | \033[0;35m |
|>7| Red | \033[0;31m |
|| Without Color|\033[0m|

Die Farben werden verwendet um die einzelnen Primfaktoren visuell besser zu trennen und ein ähnliches Bild wie im Original zu bekommen. Die Primfaktoren sollen auch selbst errechnet werden und nicht vorgespeichert sein.
Nach dem Spielfeld wird eine Leerzeile ausgegeben um das Spielfeld visuell abzutrennen.

```
-------------------------------------------------\n
```
### Rundeninformationen
Nach dem Spielfeld werden die Rundeninformationen ausgegeben. Dabei wird geprinted, welcher Spieler am Zug ist:
```
Player %c, it is your turn!\n\n
```
Verwendet wird ein 10 seitiger Würfel. Um die gewürfelten Werte zu generieren wird der als Parameter übergebene Seed an die [srand](https://www.cplusplus.com/reference/cstdlib/srand/) Funktion übergeben `srand(<seed>)`, die Zufallswerte werden danach mit `rand() % NUMBER_OF_DICE_SURFACES + 1` generiert. Die Werte werden folgendermaßen angezeigt:
```
\033[1mValue of first dice was %d\033[0m\n
```
```
\033[1mValue of second dice was %d\033[0m\n
```
Wobei der erste Würfel nicht nochmal ausgegeben wird nach Benutzung seiner Operation.
Nach den Würfelwerten werden die möglichen Rechenoperationen ausgegeben:
```
\nChoose between:\nadd: +\nsub: -\nmul: *\ndiv: /\n\n
```
### Spielereingaben
Nach den möglichen Rechenoperationen wird der Spieler aufgefordert, durch Eingabe seine gewünschte Operation zu wählen. Dazu wird ein Terminal üblicher Prompt angezeigt:
```
> 
```
Valide Kommandos sind:
- \+ : Der gewürfelte Wert wird auf den Wert, auf dem der Spieler steht, **addiert**
- \- : Der gewürfelte Wert wird von dem Wert, auf dem der Spieler steht, **subtrahiert**
- \* : Der gewürfelte Wert wird mit dem Wert, auf dem der Spieler steht, **multipliziert**
- / : Der Wert auf dem der Spieler steht wird durch den gewürfelten Wert **dividiert** (Bei Rest wird abgeschnitten, nicht gerundet z.B. 0.9 -> 0)
- **EOF** : Durch die Übergabe von EOF(Strg+D), soll das Programm sofort beendet werden (wichtig für Testsystem!)

Nach einem validen Kommando werden Spielfeld, aktueller Spieler, gewürfelte Werte und die möglichen Werte erneut ausgegeben. 
Sollte es zu einer nicht validen Eingabe kommen, soll folgende Meldung ausgegeben und nach einer erneuten Eingabe gefragt werden.
```
Invalid, again please:\n
```

Bei einer validen Eingabe soll dem Spieler mitgeteilt werden, wo sich seine Spielfigur nach der Rechenoperation befindet:
```
Player %c moved to Field %d\n
```

### Spielverlauf
Wenn zwei Spieler am gleichen Feld stehen, wurde der Spieler der zuerst dort gestanden ist geschmissen und muss wieder von vorne beginnen:
```
Player %c was busted\n
```

Der Spieler der zuerst das letzte Feld erreicht gewinnt. Dabei soll folgende Meldung ausgegeben und das Programm mit Rückgabewert 0 beendet werden.
```
Player %c won the Game\n
```


## Fehlermeldungen

Sollte die Anzahl der übergebenen Argumente nicht genau 4 entsprechen, soll der Fehlercode 1 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Wrong amount of parameters!\n
```

Sollte es sich bei einem oder mehreren Argumenten um etwas anderes als das vorgegebene Format handeln, soll der Fehlercode 2 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Invalid arguments!\n
```

Sollte die Anzahl der Spieler <= 0 oder > 4 sein, soll der Fehlercode 3 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Number of Players should be greater than 0, but smaller than 4!\n
```

Sollte die Anzahl der Felder kleiner oder gleich 0 sein, soll der Fehlercode 4 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Gamefield has to consist of at least 1 field (without zero)\n
```

Ist die gewählte Anzahl der Felder keine Primzahl, soll der Fehlercode 5 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Last field has to be prime!\n
```

Solltet ihr das Programm mit dynamischen Speicher implementieren(siehe Bonus) wollen und dem Programm geht im Laufe des Spiels der Speicher aus (malloc returnt NULL), soll der Fehlercode 6 zurückgegeben sowie folgende Fehlermeldung angezeigt werden:
```
Out of memory!\n
```

Sollte das Programm ohne Probleme durchlaufen und das Spiel ordnungsgemäß beendet werden, soll 0 zurückgegeben werden. 

**Wichtig**
Bei den Fehlermeldungen ist es wichtig die Reihenfolge zu beachten, sollte also z.B. die Anzahl der Argumente nicht genau 4 entprechen und das Format nicht passen:
`./primeclimb abc 2022 4 101`
soll  
```
Wrong amount of parameters!\n
```
mit dem Fehlercode 1 zurückgegeben werden.

## Bonus (3 Punkte)
Da ein wichtiger Teil der Programmierung in C die dynamische Speicherverwaltung ist und dieses Programm sowohl ohne dynamischem Speicher als auch mit umsetzbar ist, geben wir euch die Möglichkeit als Bonus bereits erste Erfahrungen mit der dynamischen Speicherverwaltung zu sammeln bevor diese im Assignemnt 3 verpflichtend ist. Achtet allerdings darauf, dass die entsprechende Fehlermeldung "Out of memory" sowie eine fehlerfreie Speicherverwaltung ohne Speicherlöcher vorhanden ist, da es sonst zu Punkteabzügen kommen kann. 

## Beispielausgaben
Für eine bessere Orientierung findet ihr hier eine beispielhafte Spielfeldausgabe für folgenden Programmaufrufe:
```
./primeclimb 2022 2 23
```
<img src=./images/example_output.png width="400">

```
./primeclimb 5555 2 19
```

<img src=./images/example_output2.png width="400">

## Spezifikation

- Erlaubte Bibliotheken: stdio.h stdlib.h
- Die Primfaktorzerlegung muss als Funktion implementiert werden
- Es müssen Structcs verwendet werden

## Abgabe
- Deadline: 13.05.2022 23:59
- a2.c

## Bewertung

| Kategorie | Punkte |
| ------ | ------ |
| Funktionaliät |20|
| Doku und Stil |4|
|Programmstruktur|5|
|Robustheit|4|
|Bonus|3|
