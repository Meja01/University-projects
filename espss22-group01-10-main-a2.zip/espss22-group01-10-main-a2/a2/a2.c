//-----------------------------------------------------------------------------
// a2.c
//
// In this program we are making simplified version of game primeclimb, there can bee 1, 2 or 3
// players. They all have their characters and the goal is to go on the last field. Who ever
// make it first he won. The players can't stay together at one place except at the start
// so who comes second at that place where is already one player will be boosted.
//
// Group: 1
//
// Author: 12034456
//-----------------------------------------------------------------------------
//
#include <stdio.h>
#include <stdlib.h>

struct playfield
{
  char character_of_players_;
  int number_of_field_;
  int primes_and_not_primes_[20];
};

//-----------------------------------------------------------------------------
///
/// In this function is calculated the length of a prime factors which I use 
/// after in function for printing array to determine a length of prime factors in my program.
/// This function finds prime factors and after it finds it increase a length which I need.
///
/// @param num_of_fields The argument passed from main and it represent limit that user inputsvia command line
/// This parameter helps to find prime factors as well, all numbers from 2 to num_of_fields are going 
/// through loop, so I could find length of prime factors which I use.
///
/// @return counter -> length of used prime factors
//
int lengthOfPrimesInFactorization(int num_of_fields)
{
  int counter = 0;
  int i = 2;
  while (num_of_fields > 1)
  {
    if (num_of_fields % i == 0)
    {
      counter++;
      num_of_fields /= i;
    }
    else
    {
      i++;
    }
  }
  return counter;
}

//-----------------------------------------------------------------------------
///
/// In this function I store symbols or "characters" that user inputs in an array and this function
/// is called and used in function for original playfield and prints result there. 
///
/// @param num_of_players to check number of players
/// @param char_1 To store character for first player
/// @param char_2 To store character for second player
/// @param char_3 To store character for third player
///
//
void arrayForCharacters(int num_of_players, char char_1, char char_2, char char_3)
{
  int i;
  char array[num_of_players];
  int index = 0;
  if (num_of_players == 1)
  {
    array[index] = char_1;
    index++;
  }
  else if (num_of_players == 2)
  {
    array[index] = char_1;
    index++;
    array[index] = char_2;
    index++;
  }
  else if (num_of_players == 3)
  {
    array[index] = char_1;
    index++;
    array[index] = char_2;
    index++;
    array[index] = char_3;
    index++;
  }
  for (i = 0; i < index; i++)
  {
    printf("%c", array[i]);
  }
}

//-----------------------------------------------------------------------------
///
/// In this function I am checking for prime numbers, by that I mean, I need to print prime factors
/// in third coloumn of playfield. So I check for specific numbers "prime factors" and prints them
/// with their given colours.
///
/// @param i to check if number is equal to prime factors to print them with specific colours
/// @param is_last_number this argument is needed because of spaces at the end of printing which are unnecessary,
/// both of this arguments are needed and passed from function printPrimeFactors.
///
//
void printValueInColor(int i, int is_last_number)
{
  if (i == 2)
  {
    if (is_last_number)
    {
      printf("\033[0;33m%d\033[0m", i);
    }
    else
    {
      printf("\033[0;33m%d\033[0m ", i);
    }
  }
  else if (i == 3)
  {
    if (is_last_number)
    {
      printf("\033[0;32m%d\033[0m", i);
    }
    else
    {
      printf("\033[0;32m%d\033[0m ", i);
    }
  }
  else if (i == 5)
  {
    if (is_last_number)
    {
      printf("\033[0;34m%d\033[0m", i);
    }
    else
    {
      printf("\033[0;34m%d\033[0m ", i);
    }
  }
  else if (i == 7)
  {
    if (is_last_number)
    {
      printf("\033[0;35m%d\033[0m", i);
    }
    else
    {
      printf("\033[0;35m%d\033[0m ", i);
    }
  }
  else if (i > 7)
  {
    if (is_last_number)
    {
      printf("\033[0;31m%d\033[0m", i);
    }
    else
    {
      printf("\033[0;31m%d\033[0m ", i);
    }
  }
}

//-----------------------------------------------------------------------------
///
/// In this function I am storing values of the function printValueInColor. The foor loop is there
/// to be sure that all prime factors are properly printed for each series with given length.
/// Variable "is_last_number" is there to make sure
/// that there are no space at the end.
///
/// @param array[] this prime factors need to be printed in an array
/// @param length represent the length of an series
///
///
//
void printPrimeFactors(int array[], int length)
{
  int i;
  int is_last_number = 0;
  for (i = 0; i < length; i++)
  {
    if (i == length - 1)
    {
      is_last_number = 1;
    }
    printValueInColor(array[i], is_last_number);
  }
}
//-----------------------------------------------------------------------------
///
/// In this function I am printing just one series for the playfield.
/// the function printPrimeFactors is used as well, so that both coloumns can be next to each other.
/// I am using variabe element from previous defined struct here so I could acces these elements and print them.
///
/// @param element this argument enables printing elements inside pre-defined struct and it's a variable from struct
///
//
void printPlayfield(struct playfield element)
{
  printf("\t\t%i\t\t", element.number_of_field_);
  printPrimeFactors(element.primes_and_not_primes_, lengthOfPrimesInFactorization(element.number_of_field_));
  printf("\n");
}

//-----------------------------------------------------------------------------
///
/// In this function I am using for loop and I am calling printPlayfield so that each series 
/// can be printed out. This function is only used once ant prints original playfield.
///
/// @param my_array[] This is actuall array indebted to print every series up to given length
/// @param length this argument represent number of field "limit", so that program knows when to stop printing
///
//
void printEachLineOfPlayfield(struct playfield my_array[], int length)
{
  int i;
  for (i = 0; i <= length; i++)
  {
    printPlayfield(my_array[i]);
  }
}

//-----------------------------------------------------------------------------
///
/// After the printing original playfield, this function uses for loop to move players through the table and uses
/// printPlayfield to print every next plafield.
///
/// @param my_array[] is an array and is there to print all elements from playfield inside itself
/// @param length is an argument that represent length of an array (or so to say number of field)
/// @param char_1 is the character for first player and it is here to be printed at some specific place depending on
/// passed  pointer *position_1
/// @param char_2 is the character for player two and it is here to be printed at some specific place
/// @param num_of_players this argument tells me how many players there are and depending on that how many characters
/// are going to be printed out
/// @param *position_1 is argument that is passing currently place of first character
//
void printNextPlayfields(struct playfield my_array[], int length, char char_1, char char_2, int num_of_players,
                         int *position_1)
{
  int first_player_position = 0;
  int second_player_position = 0;
  int i;
  for (i = 0; i <= length; i++)
  {
    if (num_of_players == 2)
    {
      if (i == second_player_position)
      {
        printf("%c", char_2);
      }
    }
    first_player_position = *position_1;
    if (i == first_player_position)
    {
      printf("%c", char_1);
    }
    printPlayfield(my_array[i]);
  }
}

//-----------------------------------------------------------------------------
///
/// This is the function for calculating prime factors and storing them in an array.
/// It calculates prime factors using specific formula.
///
/// @param array[] is an argument in where are prime factors stored
/// @param num_of_field this number help us define whether is prime factor or not
/// 
//
void arrayOfPrimes(int array[], int num_of_field)
{
  int counter = 0;
  int i = 2;
  while (num_of_field > 1)
  {
    if (num_of_field % i == 0)
    {
      array[counter] = i;
      counter++;
      num_of_field /= i;
    }
    else
    {
      i++;
    }
  }
}

//-----------------------------------------------------------------------------
///
/// This is a simple function that checks if given number is prime or not.
///
/// @param number the given number from command line 
///
/// @return true if the number is prime or (1), in other case falls if the number is not prime or (0).
//
int isPrime(int number)
{
  int i;
  for (i = 2; i <= number / 2; i++)
  {
    if (number % i == 0)
    {
      return 0;
    }
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is the simple function that calculates how many characters user enters. 
/// It counts the number of character as long as comes to null byte.
/// @param op_char[] This is the passed argument and it has purpose of input of valid 
/// characters in functions for operations
///
/// @return num_of_char -> int number of characters that user enters
//
int lengthOfCharacters(char op_char[])
{
  int i;
  int num_of_char = 0;
  for (i = 0; op_char[i] != '\0'; i++)
  {
    if (op_char[i] != ' ')
    {
      num_of_char++;
    }
  }
  return num_of_char;
}

//-----------------------------------------------------------------------------
///
/// This is the function that gives the user two random number, so the user can use them for operations later.
/// Two random numbers are printed and also stored in other two variable, so that operations can be made 
///
/// @param seed the given seed is passed argument from main that helps srand function to find random numbers
/// @param *first_roll argument is there to store value of first dice
/// @param *second_roll argument is there to store value of second dice
/// @param condition this checks if user is playing with first dice or with second dice.
///
//
void functionForSrandFirstTime(int seed, int *first_roll, int *second_roll, int condition)
{
  int first_dice = 0;
  int second_dice = 0;
  srand(seed);
  first_dice = rand() % 10 + 1;
  second_dice = rand() % 10 + 1;
  if (condition == 1)
  {
    printf("\033[1mValue of first dice was %d\033[0m\n", first_dice);
    printf("\033[1mValue of second dice was %d\033[0m\n", second_dice);
  }
  else if (condition == 2)
  {
    printf("\033[1mValue of second dice was %d\033[0m\n", second_dice);
  }
  *first_roll = first_dice;
  *second_roll = second_dice;
}

//-----------------------------------------------------------------------------
///
/// This is the function where user for first time enters valid symbol for operation that can be only +
/// Here I check all possible inputs so if anything else except one character that is + can be invalid operation
///
/// @param *position_1 in this argument I store poistion of first player that is given by argument first_roll
/// @param *first_roll this arguments passes the value of first dice
///
/// @return returns 0 if it is end of file and 1 if not
//
int firstOperation(int *position_1, int *first_roll)
{
  char op_char[100];
  printf("\nChoose between:\nadd: +\nsub: -\nmul: *\ndiv: /\n\n");
  printf("> ");
  if ((scanf("%s", op_char)) != EOF)
  {
    if (lengthOfCharacters(op_char) > 1)
    {
      while ((lengthOfCharacters(op_char)) > 1)
      {
        printf("Operation is invalid, try it again:\n");
        printf("> ");
        if ((scanf("%s", op_char)) == EOF)
        {
          return 0;
        }
        else
        {
          while (1)
          {
            if (op_char[0] == '+')
            {
              *position_1 += *first_roll;
              break;
            }
            else
            {
              printf("Operation is invalid, try it again:\n");
              printf("> ");
              if ((scanf("%s", op_char)) == EOF)
              {
                return 0;
              }
            }
          }
        }
      }
    }
    else
    {
      while (1)
      {
        if (op_char[0] == '+')
        {
          *position_1 += *first_roll;
          break;
        }
        else
        {
          printf("Operation is invalid, try it again:\n");
          printf("> ");
          if ((scanf("%s", op_char)) == EOF)
          {
            return 0;
          }
        }
      }
    }
  }
  else
  {
    return 0;
  }
  return 1;
}


//-----------------------------------------------------------------------------
///
/// This is the function that takes users input for every next time after the first one is excecuted before
/// It check for valid input and only mathematical operations are valid input like: "/, *, + , - ".
/// Beside That it calculates current poistion of first player.
///
/// @param *first_roll this arguments passes the value of first dice
/// @param *second_roll this arguments passes the value of second dice
/// @param *position_1 after the user enters operations in this argument is stored value of
/// calculations of first two arguments
///
/// @return returns 0 if it is end of file and 1 if not
//
int nextOperation(int *first_roll, int *second_roll, int *position_1)
{
  char op_char[100];
  printf("\nChoose between:\nadd: +\nsub: -\nmul: *\ndiv: /\n\n> ");
  if ((scanf("%s", op_char)) != EOF)
  {
    if (lengthOfCharacters(op_char) > 1)
    {
      while ((lengthOfCharacters(op_char)) > 1)
      {
        printf("Operation is invalid, try it again:\n> ");
        if ((scanf("%s", op_char)) == EOF)
        {
          return 0;
        }
        else
        {
          while (op_char[0] != '+' || op_char[0] != '-' || op_char[0] != '/' || op_char[0] != '*')
          {
            if (op_char[0] == '+')
            {
              *position_1 = *first_roll + *second_roll;
              break;
            }
            else if (op_char[0] == '-')
            {
              *position_1 = *first_roll - *second_roll;
              break;
            }
            else if (op_char[0] == '/')
            {
              *position_1 = *first_roll / *second_roll;
              break;
            }
            else if (op_char[0] == '*')
            {
              *position_1 = *first_roll * *second_roll;
              break;
            }
            else
            {
              printf("Operation is invalid, try it again:\n> ");
              if ((scanf("%s", op_char)) == EOF)
              {
                return 0;
              }
            }
          }
        }
      }
    }
    else
    {
      while (op_char[0] != '+' || op_char[0] != '-' || op_char[0] != '/' || op_char[0] != '*')
      {
        if (op_char[0] == '+')
        {
          *position_1 = *first_roll + *second_roll;
          break;
        }
        else if (op_char[0] == '-')
        {
          *position_1 = *first_roll - *second_roll;
          break;
        }
        else if (op_char[0] == '/')
        {
          *position_1 = *first_roll / *second_roll;
          break;
        }
        else if (op_char[0] == '*')
        {
          *position_1 = *first_roll * *second_roll;
          break;
        }
        else
        {
          printf("Operation is invalid, try it again:\n> ");
          if ((scanf("%s", op_char)) == EOF)
          {
            return 0;
          }
        }
      }
    }
  }
  else
  {
    return 0;
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is the function that prints original playfield with help of other functions as well.
/// After the user enters characters for players the original playfield is printed.
///
/// @param num_of_players argument that use other function for characters
/// @param char_1 represent the character for first player
/// @param char_2 represent the character for second player
/// @param char_3 represent the character for third player
/// @param num_of_fields represent the limit for printing the playfield
//
void originalPlayfield(int num_of_players, char char_1, char char_2, char char_3, int num_of_fields)
{
  int i;
  printf("\n");
  printf("-------------------------------------------------\n"
         "|Player\t\tField\t\tPrime Factors\t|\n"
         "-------------------------------------------------\n");
  arrayForCharacters(num_of_players, char_1, char_2, char_3);
  struct playfield parts;
  struct playfield my_array[num_of_fields + 1];
  for (i = 0; i <= num_of_fields; i++)
  {
    parts.number_of_field_ = i;
    arrayOfPrimes(parts.primes_and_not_primes_, parts.number_of_field_);
    my_array[i] = parts;
  }
  printEachLineOfPlayfield(my_array, num_of_fields);
  printf("-------------------------------------------------\n");
  printf("\n");
}

//-----------------------------------------------------------------------------
///
/// After the original playfield is printed out, this function is called and inside of her is printed
/// every next plafield. As long as poistion for first character is smaller then number of field 
/// the printing of playfield will be available.
///
/// @param num_of_players argument that use other function for characters
/// @param char_1 represent the character for first player
/// @param char_2 represent the character for second player
/// @param num_of_fields represent the limit for printing the playfield
/// @param seed argument that use other function to get two random numbers
///
/// @return returns 0 if the end of file is recognized and 1 if not
//
int nextPlayfields(int num_of_players, char char_1, char char_2, int num_of_fields, int seed)
{
  int position_1 = 0;
  int first_roll = 0;
  int second_roll = 0;
  int i = 0;
  struct playfield parts;
  struct playfield my_array[num_of_fields + 1];
  printf("Player %c, it is your turn!\n\n", char_1);
  functionForSrandFirstTime(seed, &first_roll, &second_roll, 1);
  while (position_1 <= num_of_fields)
  {
    if (firstOperation(&position_1, &first_roll) != 0)
    {
      printf("Player %c moved to Field %d\n", char_1, position_1);
      printf("\n");
      printf("-------------------------------------------------\n"
             "|Player\t\tField\t\tPrime Factors\t|\n"
             "-------------------------------------------------\n");
      for (i = 0; i <= num_of_fields; i++)
      {
        parts.number_of_field_ = i;
        arrayOfPrimes(parts.primes_and_not_primes_, parts.number_of_field_);
        my_array[i] = parts;
      }
      printNextPlayfields(my_array, num_of_fields, char_1, char_2, num_of_players, &position_1);
      printf("-------------------------------------------------\n");
      printf("\n");
      functionForSrandFirstTime(seed, &first_roll, &second_roll, 2);
      if (nextOperation(&first_roll, &second_roll, &position_1) != 0)
      {
        printf("Player %c moved to Field %d\n", char_1, position_1);
        printf("\n");
        printf("-------------------------------------------------\n"
               "|Player\t\tField\t\tPrime Factors\t|\n"
               "-------------------------------------------------\n");
        for (i = 0; i <= num_of_fields; i++)
        {
          parts.number_of_field_ = i;
          arrayOfPrimes(parts.primes_and_not_primes_, parts.number_of_field_);
          my_array[i] = parts;
        }
        printNextPlayfields(my_array, num_of_fields, char_1, char_2, num_of_players, &position_1);
        printf("-------------------------------------------------\n");
        printf("\n");
        if (num_of_players == 2)
        {
          printf("Player %c, it is your turn!\n\n", char_2);
        }
        functionForSrandFirstTime(seed, &first_roll, &second_roll, 1);
      }
      else
      {
        return 0;
      }
    }
    else
    {
      return 0;
    }
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is the function for first player. The player should input any character. If the the user enters
/// end of file program will terminate.
///
/// @param num_of_players check if it is value of 1
/// @param char_1 represent the character for first player that user enters 
/// @param char_2 represent the character for second player for use of other functions
/// @param char_3 represent the character for third player for use of other functions
/// @param num_of_fields represent the number of field and it is for use of other functions
/// @param seed represent the from user entered seed and it is for use of other functions
///
/// @return returns 0 if the end of file is recognized and 1 if not
//
int funcFor1Player(int num_of_players, char char_1, char char_2, char char_3, int num_of_fields, int seed)
{
  if (num_of_players == 1)
  {
    printf("Enter symbol for player 1: ");
    if ((char_1 = getchar()) != EOF)
    {
      originalPlayfield(num_of_players, char_1, char_2, char_3, num_of_fields);
      if (nextPlayfields(num_of_players, char_1, char_2, num_of_fields, seed) == 0)
      {
        return 0;
      }
    }
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is the function for that takes input from first two players. The Users should input any character.
/// If the the user enters
/// end of file program will terminate. If second User input the same character as first, 
/// program will ask for input again.
///
/// @param num_of_players check if it is value of 1
/// @param char_1 represent the character for first player that user enters 
/// @param char_2 represent the character for second player that user enters
/// @param char_3 represent the character for third player for use of other functions
/// @param num_of_fields represent the number of field and it is for use of other functions
/// @param seed represent the from user entered seed and it is for use of other functions
///
/// @return returns 0 if the end of file is recognized and 1 if not
//
int funcFor2Players(int num_of_players, char char_1, char char_2, char char_3, int num_of_fields, int seed)
{
  if (num_of_players == 2)
  {
    printf("Enter symbol for player 1: ");
    if ((char_1 = getchar()) != EOF)
    {
      printf("Enter symbol for player 2: ");
      getchar();
      if ((char_2 = getchar()) != EOF)
      {
        while (1)
        {
          getchar();
          if (char_1 != char_2)
          {
            originalPlayfield(num_of_players, char_1, char_2, char_3, num_of_fields);
            if (nextPlayfields(num_of_players, char_1, char_2, num_of_fields, seed) == 0)
            {
              return 0;
            }
            break;
          }
          else
          {
            printf("Was already chosen by player 1, enter again!\n");
            printf("Enter symbol for player 2: ");
            if ((char_2 = getchar()) == EOF)
            {
              return 0;
            }
          }
        }
      }
    }
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is function where all three characters from user input are stored. The Users should input 
/// different characters, if not, the program will ask for input again. 
/// If end of file is recognized program will terminate.
///
/// @param num_of_players check if it is value of 1
/// @param char_1 represent the character for first player that user enters 
/// @param char_2 represent the character for second player that user enters
/// @param char_3 represent the character for third player that user enters
/// @param num_of_fields represent the number of field and it is for use of other functions
/// @param seed represent the from user entered seed and it is for use of other functions
///
/// @return returns 0 if the end of file is recognized and 1 if not
//
int funcFor3Players(int num_of_players, char char_1, char char_2, char char_3, int num_of_fields, int seed)
{
  if (num_of_players == 3)
  {
    printf("Enter symbol for player 1: ");
    if ((char_1 = getchar()) != EOF)
    {
      printf("Enter symbol for player 2: ");
      getchar();
      if ((char_2 = getchar()) != EOF)
      {
        while (1)
        {
          getchar();
          if (char_1 != char_2)
          {
            printf("Enter symbol for player 3: ");
            if ((char_3 = getchar()) != EOF)
            {
              while (1)
              {
                getchar();
                if ((char_3 != char_2) && (char_3 != char_1))
                {
                  originalPlayfield(num_of_players, char_1, char_2, char_3, num_of_fields);
                  if (nextPlayfields(num_of_players, char_1, char_2, num_of_fields, seed) == 0)
                  {
                    return 0;
                  }
                  break;
                }
                else if (char_3 == char_1)
                {
                  printf("Was already chosen by player 1, enter again!\n");
                  printf("Enter symbol for player 3: ");
                  if ((char_3 = getchar()) == EOF)
                  {
                     return 0;
                  }
                }
                else if (char_3 == char_2)
                {
                  printf("Was already chosen by player 1, enter again!\n");
                  printf("Enter symbol for player 3: ");
                  if ((char_3 = getchar()) == EOF)
                  {
                     return 0;
                  }
                }
              }
            }
            break;
          }
          else
          {
            printf("Was already chosen by player 1, enter again!\n");
            printf("Enter symbol for player 2: ");
            if ((char_2 = getchar()) == EOF)
            {
               return 0;
            }
          }
        }
      }
    }
  }
  return 1;
}

//-----------------------------------------------------------------------------
///
/// This is a simple function that checks if user entered valid number of players. If valid 
/// the loop will break and program will continue and if not program will print message and terminate
///
/// @param num_of_players passed argument that tell us the number of players that is entered
///
/// @return return number 3 if the passed number is invalid and 0 if the number is valid.
//
int checkForPlayers(int num_of_players)
{
  while (1)
  {
    if (num_of_players > 0 && num_of_players < 4)
    {
      break;
    }
    else
    {
      printf("Number of Players should be greater than 0, but smaller than 4!\n");
      return 3;
    }
  }
  return 0;
}

//-----------------------------------------------------------------------------
///
/// This is a simple function that checks if user entered valid number of fields, which 
/// should be greater than 0. If valid the loop will break and program will
/// continue and if not program will print message and terminate.
///
/// @param num_of_fields passed argument that tell us the number of fields that is entered
///
/// @return return number 4 if the passed number is invalid and 0 if the number is valid.
//
int checkForNumberOfField(int num_of_fields)
{
  while (1)
  {
    if (num_of_fields > 0)
    {
      break;
    }
    else
    {
      printf("Gamefield has to consist of at least 1 field (without zero)\n");
      return 4;
    }
  }
  return 0;
}

//-----------------------------------------------------------------------------
///
/// This is a simple function that checks if user entered prime number of fields.
/// If valid the loop will break and program will
/// continue and if not program will print message and terminate.
///
/// @param num_of_fields passed argument that tell us the number of fields that is entered
///
/// @return return number 5 if the passed number is invalid and 0 if the number is valid.
//
int checkForPrimeNumberOfField(int num_of_fields)
{
  while (1)
  {
    if (!isPrime(num_of_fields))
    {
      printf("Last field has to be prime!\n");
      return 5;
    }
    else
    {
      break;
    }
  }
  return 0;
}
//-----------------------------------------------------------------------------
///
/// This is the main function and here I call functions for "Fehlermeldung" and given players
/// If the user enters correctly all numbers and characters the program is gonna print playfield "game".
/// In this function I also check if user enters valid number of arguments, which should be 4.
/// Beside that I check for valid arguments that tells us whether user entered integer or some other data dype
///
/// @param argc it counts number of inputed arguments
/// @param *argv[] it stores given arguments in itself 
///
/// @return 0
//
int main(int argc, char *argv[])
{
  if (argc != 4)
  {
    printf("Wrong amount of parameters!\n");
    return 1;
  }
  int num_of_fields = atoi(argv[3]);
  int seed = atoi(argv[1]);
  int num_of_players = atoi(argv[2]);
  char char_1 = '\0';
  char char_2 = '\0';
  char char_3 = '\0';
  char *end;
  char *etp;
  char *ptr;
  strtol(argv[1], &end, 10);
  strtol(argv[2], &etp, 10);
  strtol(argv[3], &ptr, 10);
  while (1)
  {
    if ((*end != '\0') || (*etp != '\0') || (*ptr != '\0'))
    {
      printf("Invalid arguments!\n");
      return 2;
    }
    else
    {
      break;
    }
  }
  if (checkForPlayers(num_of_players) == 3)
  {
    return 3;
  }
  if (checkForNumberOfField(num_of_fields) == 4)
  {
    return 4;
  }
  if (checkForPrimeNumberOfField(num_of_fields) == 5)
  {
    return 5;
  }
  printf("Chosen seed was: %d\n", seed);
  if (funcFor1Player(num_of_players, char_1, char_2, char_3, num_of_fields, seed) == 0)
  {
    return 0;
  }
  if (funcFor2Players(num_of_players, char_1, char_2, char_3, num_of_fields, seed) == 0)
  {
    return 0;
  }
  if (funcFor3Players(num_of_players, char_1, char_2, char_3, num_of_fields, seed) == 0)
  {
    return 0;
  }
  return 0;
}
