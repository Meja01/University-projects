# Assignment 3: Positiv Gewinnt
## Lernziel
In diesem Assignment liegt der Fokus auf File I/O und dynamischem Speicher.
Um die definierten Lernziele zu erreichen soll ein Spiel mit der folgenden Funktionalität implementiert werden.

## Beschreibung
Ziel ist es, eine ESP Version des Klassikers "Vier Gewinnt" zu implementieren.
Die Regeln des Originals lauten: 2 Spieler werfen abwechselnd Steine von oben in das Spielfeld und wer zuerst seine 4 Steine entweder in eine

- Reihe
- Spalte
- Diagonale

gebracht hat, gewinnt das Spiel.

Als Besonderheit der ESP Version kann zu Beginn einer Partie zusätzlich entschieden werden, wie viele Steine in einer Reihe/Spalte/Diagonale liegen müssen, um einen Sieg zu erzielen.
So soll es beispielsweise auch möglich sein ein "Sieben Gewinnt" zu spielen. Des Weiteren lässt sich die Spielfeldgröße jederzeit ändern.

## Programmaufruf
Das Programm soll mit 3 Kommandozeilenargumenten aufgerufen werden:
```
$ ./positivgewinnt <tokens> <width of gamefield> <height of gamefield>
```

**tokens**: Anzahl der Spielsteine für Gewinn (>=1)

**width of gamefield**: Breite des Spielfelds (>=1)

**height of gamefield**: Höhe des Spielfelds (>=1)

Beispiele: 

Ein klassisches Vier Gewinnt mit einer Spielfeldgröße von 7x6:
```
$ ./positivgewinnt 4 7 6
```

![Spielfeld](example_7x6.png "Spielfeld")

Ein Sechs Gewinnt mit einer Spielfeldgröße von 11x14:
```
$ ./positivgewinnt 6 11 14
```

![Spielfeld](example_11x14.png "Spielfeld")

## Spielablauf

Das Spiel startet mit den aufgerufenen Kommandozeilenargumenten.

Danach werfen beide Spieler abwechselnd ihre Steine von oben in das Spielfeld und wer zuerst die **tokens** Anzahl an eigenen Steinen in einer Reihe, Spalte oder Diagonale vorweisen kann gewinnt und das Spiel ist zu Ende.

Außerdem gilt:

- Rot beginnt
- Das Spiel endet mit Rückgabewert 0
- Unbedingt auf die Farben achten! Neben tokens beinhalten auch die Ausgaben der Spieler sowie Spaltenbeschriftungen Farben. Entsprechende Befehle sind der Angabe zu entnehmen (siehe Kapitel Ausgabe)!

## Befehle

***Das Spielfeld sollte nach jedem Befehl (außer surrender und save) ausgegeben werden***

### Surrender:

Der aktuelle Spieler gibt auf und überlässt dem ehrwürdigen Kontrahenten den Sieg!

```
Player 1 > surrender
Player 2 won!
```

***HINWEIS:***

Dieser Befehl sollte als erstes implementiert werden!

---
### Insert:

Wirft einen der eigenen Spielsteine ins Feld. Im folgenden Beispiel in Spalte 3 (es wird nur die Spalte eingegeben):
```
> 3
```

***Der Spielzug des Spielers endet nach einem insert-Befehl!***

---
### Extend:

Als Besonderheit können beide Spieler jederzeit und so oft sie wollen einen extend Befehl ausführen. Dieser ändert während des Spiels die Größe des Feldes. 
Der erste Wert erweitert dabei die Breite und der zweite die Höhe.

Das folgende Beispiel erhöht die Spielfeldbreite um 4 und die Spielfeldhöhe um 6:

```
> extend 4 6
```

Die vertikale Erweiterung des Spielfeldes soll dabei gleichmäßig geschehen, dh. bei oberem Beispiel werden 2 Felder an der linken Seite des Spielfeldes hinzugefügt, 2 an der rechten und 6 nach oben. Dh. die Indizes der Spielsteine wandern (siehe Beispiel am Ende der Befehlbeschreibung):

Sollte die gewünschte Erweiterung der **Breite** ungerade sein (z.B. 5), so ist der Befehl invalid und es soll eine Fehlermeldung ausgegeben werden. Eine Beispieleingabe sieht dazu wie folgt aus:
```
> extend 5 7
Invalid Command!\n
```

Auch negative Eingaben sind erlaubt (diese verkleinern das Feld entsprechend)!

Die Schwierigkeit besteht dabei die Farben der Tokens korrekt einzulesen!

extend beendet den Spielzug des aktuellen Spielers nicht!

***ACHTUNG:***

Extend darf nicht ausgeführt werden, wenn dadurch bereits eingeworfene Steine betroffen bzw. gelöscht werden würden! Oder wenn versucht wird ein unmögliches Spielfeld zu schaffen (z.B. 0 Reihen, negative Spalten etc.). Ist dies der Fall muss folgende Fehlermeldung ausgegeben werden:
```
Invalid Command\n
```

Der Spieler ist weiterhin an der Reihe.

Hier in einem Beispiel zusammengefasst:

![Spielfeld](extend_example.png "Spielfeld")

---
### Load:

Es soll außerdem möglich sein eine Spieldatei einzulesen. Diese besteht lediglich aus den Tokens (ohne Rahmen und weitere Meta-Infos). Nach einem erfolgreichen Load beginnt jeweils immer Spieler Rot.

```
> load example.txt
```

***HINWEIS:***

Die Schwierigkeit besteht darin Farben korrekt einzulesen da diese im File als String gespeichert sind. Dabei stellen Leerzeichen leere Felder dar:

```
       
       
       
       
       
\033[0;31mO\033[0m\033[0;33mO\033[0m     
```

Das obrige Spielfeld beispielsweise sieht im Programm so aus:

<img src=example_file.png width="100">

load beendet den Spielzug des aktuellen Spielers nicht!

***HINWEIS:***

Es darf davon ausgegangen werden, dass das File keine Fehler enthält! Die Spielfeldgröße soll dem des Files entsprächen.

---
### Save:

Es soll zudem möglich sein ein aktuelles Spielfeld abzuspeichern.

Dies geschieht lediglich durch save und anschließendem Filenamen. Sollte das File nicht bereits existieren, soll es erstellt werden, andernfalls überschrieben.

save beendet den Spielzug des aktuellen Spielers nicht!

**Beispiel:**

```
> save funnygame.txt
```

... speichert folgendes Spielfeld

<img src=example_file.png width="100">

in folgendes File namens `funnygame.txt`:

```
       
       
       
       
       
\033[0;31mO\033[0m\033[0;33mO\033[0m     
```
---
## Ausgabe

Das Assignment beinhaltet viele Farben welche auch im Testsystem auf Korrektheit überprüft werden.
Um die Sache daher etwas einfacher bzw. einheitlicher zu machen sind hier sämtliche Befehle angeführt welche auch so verwendet werden sollen!

---
### Tokens

Die Tokens sind gemäß dem Original dargestellt in Rot und Gelb.

Um rote Tokens zu auzugeben sollte unbedingt dieser Befehl verwendet werden:
```
printf("%s", "\033[0;31mO\033[0m");
```

Folgender Befehl für gelbe Tokens:
```
printf("%s", "\033[0;33mO\033[0m");
```

---
### Command Prompt

Auch das Command-Prompt mit Angabe des aktuellen Spielers ist farblich auszugeben. Dazu bitte jeweils die folgenden Befehl verwenden:
```
printf("\033[0;31mPlayer 1\033[0m > "); //Player 1
printf("\033[0;33mPlayer 2\033[0m > "); //Player 2
```

---

### Gewinner Ausgabe

Die Commands für den Gewinnoutput der jeweiligen Spieler:

```
printf("\033[0;31mPlayer 1\033[0m won!\n"); //Player 1 won
printf("\033[0;33mPlayer 2\033[0m won!\n"); //Player 2 won
```

---
### Spielfeldnummerierung

Zudem sind die Spalten des Spielfeldes zu beschriften.

Dabei sollten jeweils nur die Einerstellen ausgegeben werden.
Ausnahmen bilden die Zehnerstellen (Grün) und die Hunderterstellen (Blau).

Für die farbige Ausgabe einer jeweiligen Ziffer sollte unbedingt folgender Befehl verwendet werden:
```
printf("\033[0;32m%d\033[0m", number); //GREEN
printf("\033[0;34m%d\033[0m", number); //BLUE
```

---

Zusammengefasst im folgenden Beispiel-Screenshot eines "Zwei Gewinnt" mit Spielfeldwidth = 111, Spielfeldheight = 6 und bereits 3 eingeworfenen Tokens in Spalte 1 und 2:

<img src=gamefield_example.png width="800">

***HINWEIS:***

Auslagern bietet sich für die bunten Outputs super an, z.B.:
```
#define GREEN "\033[0;32m%d\033[0m"
#define BLUE "\033[0;34m%d\033[0m"

{
printf(GREEN, number);
printf(BLUE, number);
}
```

## Fehlermeldungen

Sollte die Anzahl der übergebenen Argumente nicht genau 3 entsprechen, soll der Fehlercode 1 an den User zurückgegeben werden. Zusätzlich soll folgende Fehlermeldung angezeigt werden:
```
Wrong amount of parameters!\n
```
---
Sollte es sich bei einem oder mehreren Argumenten um etwas anderes als das vorgegebene Format handeln, soll der Fehlercode 2 an den User zurückgegeben werden. Zusätzlich soll folgende Fehlermeldung angezeigt werden:
```
Invalid arguments!\n
```
---
Sollte dem Programm im Laufe des Spieles der Speicher ausgehen, soll der Fehlercode 4 an den User zurückgegeben werden. Zusätzlich soll folgende Fehlermeldung angezeigt werden :
```
Out of memory!\n
```
---
Sollte ein Command nicht erkannt oder nicht durchführbar sein, soll folgende Fehlermeldung ausgegeben werden:
```
Invalid Command\n
```

**HINWEIS**:

Auch ein Insert-Befehl an einer Spalte die bereits voll ist (in der Höhe) gilt als invalid!

---

Sollte das Programm ohne Probleme durchlaufen und das Spiel ordnungsgemäß geschlossen werden, soll 0 an den User zurückgegeben werden.

---

## Spielablauf Beispiel

```
$ ./positivgewinnt 3 7 6
```

<img src=example_game.png width="180">

## Spezifikation
* Deadline: 03.06.2022 23:59
* Abgabe: a3.c
* Das Spielfeld muss am Heap liegen
* Der Speicherverbrauch soll in Relation mit der Spielfeldgröße sein

## Bewertung
| Kategorie	 | Punkte |
| --------- |:------:|
| Funktionaliät	|   30   |
| Doku und Still |   4    |
| Programmstruktur |  4    |
| Robustheit |   6    |

Vergesst nicht auf die CheckR Fragen beim AG.
