//-----------------------------------------------------------------------------
// a3.c
//
// In this program I have made a classic game called "Four Wins". There are two players for this game
// and they are throwing the stones alternating from top of the board and whoever places first certain number
// of Stones in row or column or diagonal wins the game. The size of the playing field can be changed at any time.
//
// Group: 1
//
// Author: 12034456
//-----------------------------------------------------------------------------
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//------------------------------------------------------------------------------
///
/// This function checks for valid input from user. There is a while loop that checks for all parameters,
/// if the the value that user entered is equall or more than 1
/// the program can continue, otherwise its gona fail with the following massage in the code and return value 0.
///
/// @param tokens passed argument from the main and it is checked whether the value is equall or more than 1
/// @param width passed argument from the main and it is checked whether the value is equall or more than 1
/// @param height passed argument from the main and it is checked whether the value is equall or more than 1
///
/// @return in case of entering wrong value for this parameters it returns 0, otherwise 1.
//
int checkForValidInput(int tokens, int width, int height)
{
  while (1)
  {
    if ((tokens >= 1) && (width >= 1) && (height >= 1))
    {
      break;
    }
    else
    {
      printf("Invalid arguments!\n");
      return 0;
    }
  }
  return 1;
}

//------------------------------------------------------------------------------
///
/// This is the function that helps me discover the input after the user enters command "extend". There are two 
/// for loops that are going through the indexes of a user input and checks whether user entered integer or not at
/// specific position.
/// In case of entering integer the program will save the following integer with help of atoi function that converts
/// character string into the integer value.
///
/// @param input[] this passed argument represent user input
/// @param ex_width value of this argument represent the first value after the user enters extend command
/// @param ex_height value of this argument represent the second value after the user enters extend command
///
//
void extendFunction(char input[], int *ex_width, int *ex_height)
{
  int i = 0;
  int j = 0;
  char help_f[10] = {0};
  char help_f2[10] = {0};
  for (i = 7; i < 1000; i++)
  {
    if (('0' <= input[i]) && (input[i] <= '9'))
    {
      help_f[i - 7] = input[i];
    }
    else if (input[i] == ' ')
    {
      break;
    }
    *ex_width = atoi(help_f);
  }
  for (j = i + 1; j < 1000; j++)
  {
    if (('0' <= input[j]) && (input[j] <= '9'))
    {
      help_f2[j - i - 1] = input[j];
    }
    else if (input[j] == '\0')
    {
      break;
    }
    *ex_height = atoi(help_f2);
  }
}

//------------------------------------------------------------------------------
///
/// This is the function, where I am taking the input from player 1. There are several commands like surrender,
/// extend and save. In case of entering some of this commands, program will
/// do diffferent things (for example: save command -> it will save the whole program up to the certain point.)
/// If none of this commands are entered, program will check whether user entered integer value or something wrong.
/// In case of integer value loop will break and save that integer value, in other case user will have to repeat
/// the process untill he or she enters a valid command or integer value with valid conditions.
///
/// @param width to check whether user entered correct integer value (in range of width of program)
/// @param player_1 when I get the right value, with help of this pointer variable I am passing this value to other 
/// functions
/// @param term this value tells me that user entered save command
/// @param condition in case of entering save command program wont print a newline before entering input again
/// @param flag is value that is passed from insert function and tells me if the playfield column is filled with stones
///
/// @return in case of surrendering the game from player 1 it returns 0. In case of saving the playfield it returns 6.
/// In all other cases it returns 1.
//
int inputFromPlayer1(int width, int *player_1, int *term, int condition, int flag)
{
  int ex_width = 0;
  int ex_height = 0;
  char input[14] = {0};
  char surrender[10] = "surrender";
  char extend[7] = "extend";
  char save[5] = "save";
  if (condition != 1)
  {
    printf("\n");
  }
  printf("\033[0;31mPlayer 1\033[0m > ");
  fgets(input, sizeof input, stdin);
  while (1)
  {
    if (strstr(input, surrender))
    {
      printf("\033[0;33mPlayer 2\033[0m won!\n");
      return 0;
    }
    if (strstr(input, save))
    {
      *term = 1;
      return 6;
    }
    if (strstr(input, extend))
    {
      while (1)
      {
        extendFunction(input, &ex_width, &ex_height);
        if (ex_width % 2 == 1 || ex_height % 2 == 1)
        {
          printf("Invalid Command\n\033[0;31mPlayer 1\033[0m > ");
          fgets(input, sizeof input, stdin);
          if (strstr(input, extend))
          {
            extendFunction(input, &ex_width, &ex_height);
            if (strstr(input, surrender))
            {
              printf("\033[0;33mPlayer 2\033[0m won!\n");
              return 0;
            }
          }
        }
        else
        {
          printf("\033[0;31mPlayer 1\033[0m > ");
          fgets(input, sizeof input, stdin);
          if (strstr(input, surrender))
          {
            printf("\033[0;33mPlayer 2\033[0m won!\n");
            return 0;
          }
          *player_1 = atoi(&input[0]);
          if (*player_1 >= 1 && *player_1 <= width)
          {
            break;
          }
        }
      }
    }
    *player_1 = atoi(&input[0]);
    if (*player_1 >= 1 && *player_1 <= width && flag == 0)
    {
      break;
    }
    else
    {
      printf("Invalid Command\n\033[0;31mPlayer 1\033[0m > ");
      fgets(input, sizeof input, stdin);
      if (strstr(input, surrender))
      {
        printf("\033[0;33mPlayer 2\033[0m won!\n");
        return 0;
      }
      flag = 0;
    }
  }
  return 1;
}

//------------------------------------------------------------------------------
///
/// This is the function, where I am taking the input from player 2. There is one
/// command to check and that is suerrender. In case of entering command surrender, the program will declare a winner
/// and pass the return value 0.
/// If this command is not entered, program will check whether user entered integer value or something wrong.
/// In case of integer value loop will break and save that integer value, in other case user will have to repeat
/// the process untill he or she enters a valid command or integer value with valid conditions.
///
/// @param width to check whether user entered correct integer value (in range of width of program)
/// @param player_2 when I get the right value, with help of this pointer variable I am passing this value to other 
/// functions
/// @param flag is value that is passed from insert function and tells me if the playfield column is filled with stones
///
/// @return in case of surrendering the game from player 2 it returns 0.
/// In all other cases it returns 1.
//
int inputFromPlayer2(int *player_2, int width, int flag)
{
  char input[14] = {0};
  char surrender[10] = "surrender";
  printf("\n");
  printf("\033[0;33mPlayer 2\033[0m > ");
  fgets(input, sizeof input, stdin);
  while (1)
  {
    if (strstr(input, surrender))
    {
      printf("\033[0;31mPlayer 1\033[0m won!\n");
      return 0;
    }
    *player_2 = atoi(&input[0]);
    if (*player_2 >= 1 && *player_2 <= width && flag == 0)
    {
      break;
    }
    else
    {
      printf("Invalid Command\n");
      printf("\033[0;33mPlayer 2\033[0m > ");
      fgets(input, sizeof input, stdin);
      if (strstr(input, surrender))
      {
        printf("\033[0;31mPlayer 1\033[0m won!\n");
        return 0;
      }
      flag = 0;
    }
  }
  return 1;
}

//------------------------------------------------------------------------------
///
/// In this function I am calculating how many "onestones" are going to be used in the last line of gamefield.
/// There is a foor lop that is filling the array with specific values and when it comes to number 10, it will incrase
/// number of onestones.
///
/// @param width represent the limit, up to the numbers should be entered in array.
///
/// @return it always returns number of stones that needs to be used.
//
int numberOFOneStones(int width)
{
  int second_array[width];
  int index = 1;
  int num_of_stones = 0;
  int second_index = 10;
  int i = 0;
  for (i = 1; i <= width; i++)
  {
    second_array[i] = index;
    if (index == second_index)
    {
      num_of_stones++;
      index = 0;
    }
    index++;
  }
  return num_of_stones;
}

//------------------------------------------------------------------------------
///
/// The playfield should be on heap. In this function I am allocating a memory for my 2D array by using calloc, for
/// loop and specific parameters, so that all memory for my plafield can be saved. After allocating memory,
/// I am also assigning elements to my 2D array.
///
/// @param height represent the height of playfield (of 2D array)
/// @param width represent the width of playfield (of 2D array)
///
/// @return in case of running out of memory it returns pointer variable memory with value NULL, in
/// all other cases it returns 2D pointer array.
//
char **createField(int height, int width)
{
  int i = 0;
  int j = 0;
  char **memory = NULL;
  char **array = (char **)calloc((height + 1) * sizeof(char *), sizeof(char *));
  for (i = 0; i < height; i++)
  {
    array[i] = (char *)calloc(width * sizeof(char), sizeof(char));
  }
  if(array == NULL)
  {
    printf("Out of memory!\n");
    return memory;
  }
  for (i = 0; i < height; i++)
  {
    for (j = 0; j < width; j++)
    {
      array[i][j] = ' ';
    }
  }
  return array;
}

//------------------------------------------------------------------------------
///
/// In this function I am saving the positions of first player, also check for win and filled columns.
/// With help of for loop, at specific index of 2D array
/// I am trrying to compare if at that index is space or not. In case of space, I am putting a value 1,
/// otherwise it will go to an index above (height--) as long as there is something other than space.
/// This function also checks if user entered certain number of stones vertikaly one after another.
///
/// @param array the passed argument is pointer of 2D array, that represent my playfield
/// @param player_1 it represent the value that user entered for first player, and helps to determine his positions in 
/// playfield.
/// @param height it represents the height of playfield and helps to check indexes in 2D array.
/// @param tokens it represent the value that first player needs to have in vertikaly line in order to achieve a win.
/// @param flag it sets value to 1 if the column in playfield is fully filled.
///
/// @return in case that first player has fulfilled condition to win the game, it returns 1. In all other cases returns
/// 0.
//
int insertFirstPlayer(char **array, int *player_1, int height, int tokens, int *flag)
{
  int counter = 0;
  int for_win = 1;
  int height_copy = height;
  for (counter = 0; counter <= height_copy; counter++)
  {
    if (array[height - 1][*player_1 - 1] == ' ')
    {
      array[height - 1][*player_1 - 1] = '1';
      if (array[height_copy - height_copy][*player_1 - 1] != ' ')
      {
        *flag = 1;
      }
      break;
    }
    else
    {
      height--;
      for_win++;
    }
  }
  if (for_win == tokens)
  {
    return 1;
  }
  return 0;
}

//------------------------------------------------------------------------------
///
/// In this function I am saving the positions of second player, also check for win and filled columns.
/// With help of for loop, at specific index of 2D array
/// I am trrying to compare if at that index is space or not. In case of space, I am putting a value 2, 
/// otherwise it will go to an index above (height--) as long as there is something other than space.
/// This function also checks if user entered certain number of stones vertikaly one after another.
///
/// @param array the passed argument is pointer of 2D array, that represent my playfield
/// @param player_2 it represent the value that user entered for second player, and helps to determine his positions in 
/// playfield.
/// @param height it represents the height of playfield and helps to check indexes in 2D array.
/// @param tokens it represent the value that second player needs to have in vertikaly line in order to achieve a win.
/// @param flag it sets value to 1 if the column in playfield is fully filled.
///
/// @return in case that first player has fulfilled condition to win the game, it returns 1. In all other cases returns
/// 0.
//
int insertSecondPlayer(char **array, int *player_2, int height, int tokens, int *flag)
{
  int counter = 0;
  int for_win = 1;
  int height_copy = height;
  for (counter = 0; counter <= height_copy; counter++)
  {
    if (array[height - 1][*player_2 - 1] == ' ')
    {
      array[height - 1][*player_2 - 1] = '2';
      if (array[height_copy - height_copy][*player_2 - 1] != ' ')
      {
        *flag = 1;
      }
      break;
    }
    else
    {
      height--;
      for_win++;
    }
  }
  if (for_win == tokens)
  {
    return 1;
  }
  return 0;
}

//------------------------------------------------------------------------------
///
/// In this function I am freeing the memory that is early allocated. With help of already allocated 2D array, the
/// program is going through foor lop and it frees memory through the whole 2D array.
///
/// @param array the passed argument is pointer of 2D array, that represent my playfield
/// @param height represent the limit up to the memory needs to be freeded.
///
//
void freeField(char **array, int height)
{
  int i = 0;
  for (i = 0; i <= height; i++)
  {
    free(array[i]);
  }
  free(array);
}

//------------------------------------------------------------------------------
///
/// In this function my program saves the current playfield. First it opens the file where the game should be saved, 
/// second it goes through the 2 for loops and wherever needs to be printed something (stone in color or space),
/// it saves that at that specific position. After the saving the game, file will close.
///
/// @param array the passed argument is pointer of 2D array, that represent my playfield
/// @param height it represent the (height of playfield) limit up to the first loop should execute
/// @param width it represent the (width of playfield) limit up to the second loop should execute
///
//
void saveCurrentField(char **array, int height, int width)
{
  FILE *ptr;
  int i = 0;
  int t = 0;
  ptr = fopen("tests/19/save_file.txt", "w");
  for (i = 0; i < height; i++)
  {
    for (t = 0; t < width; t++)
    {
      if (strncmp(&array[i][t], "1", 1) == 0)
      {
        fprintf(ptr, "\033[0;31mO\033[0m");
      }
      else if (strncmp(&array[i][t], "2", 1) == 0)
      {
        fprintf(ptr, "\033[0;33mO\033[0m");
      }
      else
      {
        fprintf(ptr, " ");
      }
    }
    if (i != height - 1)
    {
      fprintf(ptr, "\n");
    }
  }
  fclose(ptr);
}

//------------------------------------------------------------------------------
///
/// This is the function where the last line of gamefield has been printed. There is a for loop that is going through
/// indexes and fills the array with specific values. Besides that it prints the Onestones inside of that line too,
/// whenever it comes to specific value in an array. Another function -numberOFOneStones- is called in this function
/// and it represent the number of stones that is going to be printed out. Because of that is condition "width-length"
/// so that the loop does not print more values than it should. After execution of the whole for loop, values inside
/// of loop are reseted, so that loop can start again with the same values.
///
/// @param width it represent the (width of playfield) limit up to the loop should execute
//
void printLastLineOfField(int width)
{
  int i = 0;
  int index = 1;
  int second_counter = 0;
  int second_array[width];
  int length = 0;
  int second_index = 9;
  length = numberOFOneStones(width);
  printf("-");
  for (i = 1; i <= width - length; i++)
  {
    second_array[i] = index;
    printf("%d", index);
    if (index == second_index)
    {
      index = 0;
      if (i % 90 == 0)
      {
        second_counter = 1;
        printf("\033[0;34m%d\033[0m", second_counter);
        second_counter++;
      }
      else
      {
        second_counter++;
        printf("\033[0;32m%d\033[0m", second_counter);
      }
    }
    index++;
  }
  printf("-\n");
  index = 1;
  second_counter = 0;
}

//------------------------------------------------------------------------------
///
/// This is the simple function that checks for win in one direction (vertikaly). If the passed paremeter ( *win) 
/// is equal to 1, program is gonna declare a winner (first player) free the memory and return a value 0.
///
/// @param array the passed argument is pointer of 2D array, that represent my playfield
/// @param height this parameter is needed for function that frees the memory
/// @param win represent passed paremeter that determines if the first player wins
///
/// @return in case a win of a first player it returns 0, otherwise 1.
//
int checkForWin(char **array, int height, int *win)
{
  if (*win == 1)
  {
    printf("\n\033[0;31mPlayer 1\033[0m won!\n");
    freeField(array, height);
    return 0;
  }
  return 1;
}

//------------------------------------------------------------------------------
///
/// This is the function where I am printing the playfield. First, original playfield, without inserted stones
/// from players, will be printed. After that there is algrorithm,
/// that determines which player is on turn and takes input from them.
/// After user entered input, insert function for both players will be executed and saved vaules are gona be compared
/// with strncmp function and in case that comparison is true, stones are gonna be printed specific colours.
/// The whole game is in loop until the first player wins. In case of entering some commands, for example surrender,
/// program will recognize it with help of variable "return_value" and pass the return value 0 to the main
/// after freeing the memory.
///
/// @param array array the passed argument is pointer of 2D array, that represent my playfield
/// @param width represent width of playfield
/// @param height represent height of playfield
/// @param player_1 represent value that first player entered
/// @param player_2 represent value that second player entered
/// @param tokens this parameter is needed because of calling other functions
///
/// @return in case of surrendering one of the players or if first player wins, program will return 0,
/// in all other cases returns 1.
//
int printPlayfield(char **array, int width, int height, int *player_1, int *player_2, int tokens)
{
  int flag = 0;
  int term = 0;
  int i = 0;
  int counter = 0;
  int return_value = 0;
  int player_turn = 0;
  int t = 0;
  int win = 0;
  int second_win = 0;
  int height_copy = height;
  while (win != 1)
  {
    while (counter >= 1)
    {
      if (player_turn == 1)
      {
        return_value = inputFromPlayer1(width, player_1, &term, 0, flag);
        if (return_value == 0)
        {
          freeField(array, height);
          return 0;
        }
        if (return_value == 6)
        {
          if (term == 1)
          {
            saveCurrentField(array, height, width);
          }
          return_value = inputFromPlayer1(width, player_1, &term, 1, flag);
        }
        win = insertFirstPlayer(array, player_1, height, tokens, &flag);
        player_turn = -1;
        break;
      }
      else if (player_turn == 0)
      {
        return_value = inputFromPlayer2(player_2, width, flag);
        if (return_value == 0)
        {
          freeField(array, height);
          return 0;
        }
        second_win = insertSecondPlayer(array, player_2, height, tokens, &flag);
        break;
      }
    }
    counter++;
    printf("\n");
    for (i = 0; i < height_copy; i++)
    {
      printf("|");
      for (t = 0; t < width; t++)
      {
        if (strncmp(&array[i][t], "1", 1) == 0)
        {
          printf("\033[0;31mO\033[0m");
        }
        else if (strncmp(&array[i][t], "2", 1) == 0)
        {
          printf("\033[0;33mO\033[0m");
        }
        else
        {
          printf(" ");
        }
      }
      printf("|\n");
    }
    printLastLineOfField(width);
    player_turn++;
  }
  if (checkForWin(array, height, &win) == 1)
  {
    freeField(array, height);
  }
  return 1;
}

//------------------------------------------------------------------------------
/// 
/// This is the main function. In this function, first I check for valid inputs via the command line.
/// The number of arguments should be exactly 4. If it is the right number of arguments program will save the given
/// values from the command line. After that it checks whether user entered valid arguments (integers).
/// If everything is good with inputed values program continues to work properly. The very important functions ares
/// called in this function so that program could work, like "createField" function where I have allocated memory and
/// function "printPlayfield" where I am printing the playfield. In this function I am comparing their return values.
/// In case of getting a value 0 from any of them program will terminate.
/// 
///
/// @param argc it counts number of inputed arguments
/// @param *argv[] it stores given arguments
///
/// @return in case of wrong amount of arguments 1, in case of invalid arguments 2, otherwise 0.
//
//-------------------------------------------------- Main -----------------------------------------------------------
int main(int argc, char *argv[])
{
  if (argc != 4)
  {
    printf("Wrong amount of parameters!\n");
    return 1;
  }
  int tokens = atoi(argv[1]);
  int width = atoi(argv[2]);
  int height = atoi(argv[3]);
  int player_1 = 0;
  int player_2 = 0;
  char *first;
  char *second;
  char *third;
  strtol(argv[1], &first, 10);
  strtol(argv[2], &second, 10);
  strtol(argv[3], &third, 10);
  char **memory = NULL;
  char **array = NULL;
  if((array = createField(height, width)) == memory)
  {
    return 4;
  }
  while (1)
  {
    if ((*first != '\0') || (*second != '\0') || (*third != '\0'))
    {
      printf("Invalid arguments!\n");
      return 2;
    }
    else
    {
      break;
    }
  }
  if (checkForValidInput(tokens, width, height) == 0)
  {
    return 2;
  }
  if (printPlayfield(array, width, height, &player_1, &player_2, tokens) == 0)
  {
    return 0;
  }
  return 0;
}
